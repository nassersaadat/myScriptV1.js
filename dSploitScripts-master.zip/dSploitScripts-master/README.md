dSploitScripts
==============

An Android app that allows easy downloading for scripts to inject into webpages with dSploit. Created by jkush321 (InfaCraft).

-------------------------------

Download
==============
First, download [dSploit] from here.

Download the app from Google Play [here][dSploitScriptsGPlay].

-------------------------------

License
==============
All content is licensed under the GPL v3.

NOTE: The [dSploit][dSploit] app is not officially affiliated with me, and is also licensed under GPL.

------------------------------

Submitting A Script
==============
See the submitting a script section at the [dSploitScripts Repo][dSploitScriptsRepo].

------------------------------

Donations
==============
Thank you for considering a donation, these will be set up soon!




[dSploit]: http://dsploit.net
[dSploitScriptsRepo]: http://github.com/infacraft/dsploitscriptsrepo
[InfaCraft]: http://infacraft.net
[dSploitScriptsGPLAY]: https://play.google.com/store/apps/details?id=net.infacraft.dsploitscripts
[dssemail]: mailto:dsploitscripts@infacraft.net